//
//  Items.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import Foundation
import UIKit

struct Items {
    
    struct Keys {
        static let api = "a99fb7aa219419a4339782394a770f23"
    }
    
    struct Links {
        static let apiUrl = "https://api.themoviedb.org/3/"
        static let imageUrl = "https://image.tmdb.org/t/p/w500/"
        static let trendingUrl = "\(apiUrl)trending/movie/day?api_key=\(Keys.api)&language=ru-RU&page=1"
        static let kinoKzUrl = "https://kino.kz/_next/data/tDFtcKxwKT6HeErBbfszj/cinemas.json"
    }
    
    struct Identifiers {
        static let categoryCollectionViewCell = "CategoryCollectionViewCell"
        static let trendingCollectionViewCell = "TrendingCollectionViewCell"
        static let categoryTableViewCell = "CategoryTableViewCell"
        static let movieCollectionViewCell = "MovieCollectionViewCell"
        static let placeCollectionViewCell = "PlaceCollectionViewCell"
        static let placeTableViewCell = "PlaceTableViewCell"
    }
    struct Values {
        
    }
    struct Colors {
        
    }
}

enum Category: String, CaseIterable {
    case all = "🔥All"
    case streaming = "🎞️Streaming"
    case onTV = "📺OnTV"
    case inTheaters = "🍿In Theaters"
}

