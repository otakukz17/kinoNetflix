//
//  Items.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import Foundation
import UIKit

struct Items {
    
    struct Keys {
        static let api = "API_KEY"
    }
    
    struct Identifiers {
        static let categoryCollectionViewCell = "CategoryCollectionViewCell"
        static let trendingCollectionViewCell = "TrendingCollectionViewCell"
        static let categoryTableViewCell = "CategoryTableViewCell"
        static let movieCollectionViewCell = "MovieCollectionViewCell"
    }
    struct Values {
        
    }
    struct Colors {
        
    }
}

enum Category: String, CaseIterable {
    case all = "🔥All"
    case streaming = "🎞️Streaming"
    case onTV = "📺OnTV"
    case inTheaters = "🍿In Theaters"
}

