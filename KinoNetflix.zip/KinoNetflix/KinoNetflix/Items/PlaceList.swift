//
//  PlaceList.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import Foundation
import UIKit

class PlaceList {
    var places = [Place] ()
    
    init() {
        let place1 = Place(name: "Cinemax Shymkent Multiplex", address: "пл. Аль-Фараби 3/1, ТРЦ \"Shymkent Plaza\"", image: UIImage(named: "cinema")!)
        let place2 = Place(name: "Kinopark 5 Mega Planet Shymkent", address: "ул. Кунаева, уг. ул. Тауке Хана, ТРЦ \"Mega Planet Shymkent\"", image: UIImage(named: "cinema")!)
        let place3 = Place(name: "Kinopark 4 Nauryz Park", address: "пр. Байдибек Би 25, ТРЦ \"Nauryz Park\", 2-й этаж", image: UIImage(named: "cinema")!)
        let place4 = Place(name: "Kinopark 5 Hyper House", address: "ул. М.Х. Дулати, 200А, ТЦ \"Hyper House\"", image: UIImage(named: "cinema")!)
        let place5 = Place(name: "Pixel Family Cinema", address: "ул. Т.Рыскулова 49А, ТРЦ \"Север\", 3-й этаж", image: UIImage(named: "cinema")!)
        let place6 = Place(name: "Арсенал 3D", address: "ул. Тауке хана(выше ул. Сайрам), автодорога №1, ТРЦ \"Фиркан city\"", image: UIImage(named: "cinema")!)
        let place7 = Place(name: "Русский драматический театр", address: "ул. Аскарова, 45", image: UIImage(named: "cinema")!)
        let place8 = Place(name: "Спортивный комплекс", address: "ул. Казиева 2А", image: UIImage(named: "cinema")!)
        let place9 = Place(name: "Наш Бар", address: "пр. Абая, 28", image: UIImage(named: "cinema")!)
        let place10 = Place(name: "Ледовый дворец", address: "ул. Желтоксан, 15/2", image: UIImage(named: "cinema")!)
        let place11 = Place(name: "Atlas", address: "ул. Торекулова,  18", image: UIImage(named: "cinema")!)
        places = [place1, place2, place3, place4, place5, place6, place7, place8, place9, place10, place11]
    }
}
