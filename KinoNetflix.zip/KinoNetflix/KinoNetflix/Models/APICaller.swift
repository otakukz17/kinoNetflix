//
//  APICaller.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import Foundation

struct APICaller {
    
    func fetchRequest() {
        let urlString = "URL"
        guard let url = URL(string: urlString) else { fatalError("Incorrect Link")}
        let task = URLSession.shared.dataTask(with: url) {data, _, error in
            if let data, error == nil {
                print (data)
            }
        }
        task.resume()
    }
    
    func parseJSON() {
        
    }
}
