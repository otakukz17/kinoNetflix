//
//  KinoKzAPICaller.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 31.01.2023.
//

import Foundation

protocol KinoKZDelegate {
    func didUpdatePlaceList(with placeList: [PlaceModel])
    func didFailWithError(_ error: Error)
}

struct KinoKzAPICaller {
    var delegate: KinoKZDelegate?
    
    func kinoKzFetchRequest() {
        let urlString = Items.Links.kinoKzUrl
        guard let url = URL(string: urlString) else { fatalError("Incorrect Link KinoKz")}
        let task = URLSession.shared.dataTask(with: url) {data, _, error in
            if let data, error == nil {
                if let placeList = parsePlaceJSON(data) {
                    delegate?.didUpdatePlaceList(with: placeList)
                } else {
                    delegate?.didFailWithError(error!)
                }
            } else {
                delegate?.didFailWithError(error!)
            }
        }
        task.resume()
    }
    
    func parsePlaceJSON(_ data: Data) -> [PlaceModel]? {
        var placeList: [PlaceModel] = []
        do {
            let decodedData = try JSONDecoder().decode(PlaceData.self, from: data)
            for place in decodedData.pageProps.cinemas {
                let placeModel = PlaceModel(name: place.name, address: place.address, smallPoster: place.small_poster)
                placeList.append(placeModel)
            }
        } catch {
            print ("ParsePlaseJSONerror____\(error)")
            return nil
        }
        return placeList
    }
    
}
