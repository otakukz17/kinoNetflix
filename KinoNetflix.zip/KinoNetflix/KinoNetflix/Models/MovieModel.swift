//
//  File.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 31.01.2023.
//

import Foundation

struct MovieModel {
    
    let adult: Bool
    let backdropPath: String
    let id: Int
    let title: String
    let overview: String
    let posterPath: String
    let mediaType: String
    let genreIds: [Int]
    let releaseDate: String
    let voteAverage: Double
    
}
