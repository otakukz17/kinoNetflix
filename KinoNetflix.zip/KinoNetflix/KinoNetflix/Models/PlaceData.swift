//
//  PlaceData.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 31.01.2023.
//

import Foundation

struct PlaceData : Decodable {
    let pageProps: PageProps
}

struct PageProps: Decodable {
    let cinemas: [Cinemas]
}

struct Cinemas: Decodable {
    let name: String
    let address: String
    let small_poster: String
}
