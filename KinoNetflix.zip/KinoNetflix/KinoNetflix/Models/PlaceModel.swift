//
//  PlaceModel.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 31.01.2023.
//

import Foundation

struct PlaceModel {
    
    let name: String
    let address: String
    let smallPoster: String
    
}
