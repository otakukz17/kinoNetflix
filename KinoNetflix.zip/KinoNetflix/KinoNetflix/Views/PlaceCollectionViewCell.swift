//
//  PlaceCollectionViewCell.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import UIKit

final class PlaceCollectionViewCell: UICollectionViewCell {
    
    private let wholeView = UIView()
    
    
    private lazy var posterImageView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = UIImage(named: "cinema")
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 5
        return imageView
    } ()
    
    private lazy var cinemaNameLabel: UILabel = {
        let label = UILabel()
        label.text = "Какой-то CINEMA"
        label.numberOfLines = 2
        label.font = UIFont.boldSystemFont(ofSize: label.font.pointSize)
        label.sizeToFit()
        label.lineBreakMode = .byWordWrapping
        return label
    } ()
    
    private lazy var addressLabel: UILabel = {
        let label = UILabel()
        label.numberOfLines = 2
        label.text = "ул. Пушкина 1"
        label.sizeToFit()
        label.textColor = .systemGray2
        label.lineBreakMode = .byWordWrapping
        return label
    } ()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupViews()
        setupConstrains()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configure(with place: PlaceModel) {
        cinemaNameLabel.text = place.name
        addressLabel.text = place.address
        
        guard let url = URL(string: place.smallPoster) else {
            fatalError("Bad poster url")
        }
        DispatchQueue.main.async {
            self.posterImageView.kf.setImage(with: url)
        }
    }

}

//MARK: - Setup views and constraints

private extension PlaceCollectionViewCell {
    
    func setupViews() {
        contentView.addSubview(wholeView)
        wholeView.addSubview(posterImageView)
        wholeView.addSubview(cinemaNameLabel)
        wholeView.addSubview(addressLabel)
    }
    
    func setupConstrains() {
        wholeView.snp.makeConstraints { make in
            make.edges.equalToSuperview().inset(5)
        }
        posterImageView.snp.makeConstraints { make in
            make.width.equalTo(100)
            make.height.equalTo(100)
            make.left.equalTo(15)
            make.top.equalTo(5)
            make.bottom.equalTo(-5)
        }
        cinemaNameLabel.snp.makeConstraints { make in
            make.left.equalTo(posterImageView.snp.right).offset(10)
            make.top.equalTo(10)
        }
        addressLabel.snp.makeConstraints { make in
            make.left.equalTo(cinemaNameLabel.snp.left)
            make.top.equalTo(cinemaNameLabel.snp.bottom).offset(10)
            make.bottom.equalTo(-10)
            make.right.equalTo(0)
        }
    }
}
