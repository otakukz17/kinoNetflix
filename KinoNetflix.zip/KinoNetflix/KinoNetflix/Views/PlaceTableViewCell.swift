//
//  PlaceTableViewCell.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import UIKit

class PlaceTableViewCell: UITableViewCell {
    var placeList: [PlaceModel] = []
    
    private lazy var placeCollectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collectionView.showsVerticalScrollIndicator = false
        collectionView.register(PlaceCollectionViewCell.self, forCellWithReuseIdentifier: Items.Identifiers.placeCollectionViewCell)
        return collectionView
    } ()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?){
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        placeCollectionView.dataSource = self
        placeCollectionView.delegate = self
        
        setupViews()
        setupConstrains()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
    
//MARK: - Collection view data source and delegate methods

extension PlaceTableViewCell: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: Items.Identifiers.placeCollectionViewCell, for: indexPath) as! PlaceCollectionViewCell
        cell.backgroundColor = .green
        cell.clipsToBounds = true
        cell.layer.cornerRadius = 10
        return cell
    }
}

extension PlaceTableViewCell: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let height = collectionView.frame.size.height
        return CGSize(width: height/2, height: height)
    }
}

//MARK: - Setup views and constraints

private extension PlaceTableViewCell {
 
    func setupViews() {
        contentView.addSubview(placeCollectionView)
    }
    
    func setupConstrains() {
        placeCollectionView.snp.makeConstraints { make in
            make.edges.equalToSuperview()
        }
    }
}
