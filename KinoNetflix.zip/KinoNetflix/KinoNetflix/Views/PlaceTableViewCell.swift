//
//  PlaceTableViewCell.swift
//  KinoNetflix
//
//  Created by Kydyrgazy Sailau on 30.01.2023.
//

import UIKit

class PlaceTableViewCell: UITableViewCell {

    var place: Place! {
        didSet {
            self.updateUI()
        }
    }
    
    let image = UIImageView()
    let name = UILabel()
    let address = UILabel()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?){
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        self.contentView.addSubview(image)
        image.snp.makeConstraints { make in
            make.width.equalTo(100)
            make.height.equalTo(100)
            make.left.equalTo(15)
            make.top.equalTo(5)
            make.bottom.equalTo(-5)
        }
        image.contentMode = .scaleAspectFill
        image.clipsToBounds = true
        
        self.contentView.addSubview(name)
        name.snp.makeConstraints { make in
            make.left.equalTo(image.snp.right).offset(10)
            make.top.equalTo(10)
        }
        
        self.contentView.addSubview(address)
        address.snp.makeConstraints { make in
            make.left.equalTo(name.snp.left)
            make.top.equalTo(name.snp.bottom).offset(10)
            make.bottom.equalTo(-10)
            make.right.equalTo(0)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateUI() {
        name.text = place.name
        address.text = place.address
        image.image = place.image
    }

}

class Place {
    let name: String
    let address: String
    let image: UIImage
    
    init(name: String, address: String, image: UIImage) {
        self.name = name
        self.address = address
        self.image = image
    }
}
